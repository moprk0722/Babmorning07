package kr.co.Board;

import java.util.List;

import kr.co.Board.BoardDTO;


public interface BoardDAO {
	//게시판 전체 글 목록
	public List<BoardDTO> boardList();
	
	//게시판 디테일 선택 조회
	public BoardDTO getBoardDetail(int b_number);
	
	//게시판 글 쓰기
	public int boardRegister(BoardDTO boardDTO);
	
	//게시판 글 수정
	public void boardUpdate(BoardDTO boardDTO);
	
	//게시판 글 삭제
	public void boardDelete(int b_number);
	
	//조회수 증가
	public void boardReadCnt(int b_number);
	
	//게시글 좋아요
	public void boardLike(int b_number);
	
	//게시글 싫어요
	public void boardHate(int b_number);
	
	//게시글 좋아요 +카운트
	public void boardLikeCnt(int b_number);
	
	//게시글 좋아요 +카운트
	public void boardHateCnt(int b_number);
	
	////////////댓글///////////////////////////
	//댓글 조회
	public List<BoardReplyDTO> getReply(int b_number);
	
	//댓글 작성
	public int replyRegister(BoardReplyDTO boardReplyDTO);
	
	//댓글 수정
	public void replyUpdate(BoardReplyDTO boardReplyDTO);
	//댓글 삭제
	public void replyDelete(int re_number);
	
	//////////페이징///////////////////////////////////////
	public List<BoardDTO> listCriteria(Criteria criteria) throws Exception;
	public List<BoardDTO> listPaging(int page) throws Exception;
}

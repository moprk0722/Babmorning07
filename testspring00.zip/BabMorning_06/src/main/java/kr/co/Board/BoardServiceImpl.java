package kr.co.Board;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class BoardServiceImpl implements BoardService{

	@Inject
	private BoardDAO boardDAO;
	
	//게시판 글 전체 목록 보기
	@Override
	public List<BoardDTO> boardList() {
		
		return boardDAO.boardList();
	}

	//게시판 글 선택 조회
	@Override
	public BoardDTO getBoardDetail(int b_number) {
		return boardDAO.getBoardDetail(b_number);
	}

	//게시판글쓰기
	@Override
	public int boardRegister(BoardDTO boardDTO) {
		return boardDAO.boardRegister(boardDTO);
	}

	//게시글 수정
	@Override
	public void boardUpdate(BoardDTO boardDTO) {
		boardDAO.boardUpdate(boardDTO);
	}
	
	//게시글 삭제
	@Override
	public void boardDelete(int b_number) {
		boardDAO.boardDelete(b_number);
	}

	//조회수 증가
	@Override
	public void boardReadCnt(int b_number) {
		boardDAO.boardReadCnt(b_number);
	}
	
	//게시글 좋아요
	@Override
	public void boardLike(int b_number) {
		boardDAO.boardLike(b_number);
	}

	//게시글 싫어요
	@Override
	public void boardHate(int b_number) {
		boardDAO.boardHate(b_number);		
	}

	//게시글 좋아요 + 카운트
	@Override
	public void boardLikeCnt(int b_number) {
		System.out.println("============좋아요 보드서비스=================");
		boardDAO.boardLikeCnt(b_number);
		
	}
	
	//게시글 좋아요 - 카운트
	@Override
	public void boardHateCnt(int b_number) {
		boardDAO.boardHateCnt(b_number);
	}
	
	//////////////////////댓글//////////////////////////////
	
	//댓글조회
	@Override
	public List<BoardReplyDTO> getReply(int b_number) {
		return boardDAO.getReply(b_number);
	}

	//댓글 작성
	@Override
	public int replyRegister(BoardReplyDTO boardReplyDTO) {
		return boardDAO.replyRegister(boardReplyDTO);
	}

	//댓글 수정
	@Override
	public void replyUpdate(BoardReplyDTO boardReplyDTO) {
		boardDAO.replyUpdate(boardReplyDTO);
	}

	//댓글삭제
	@Override
	public void replyDelete(int re_number) {
		boardDAO.replyDelete(re_number);
	}

	//////////////페이징///////////////////////////////////////
	@Override
	public List<BoardDTO> listCriteria(Criteria criteria) throws Exception {
		return boardDAO.listCriteria(criteria);
	}

	@Override
	public List<BoardDTO> listPaging(int page) throws Exception {
		return boardDAO.listPaging(page);
	}

	

	

	

	
	

	

	
	
	
	
	
	
	
}

package kr.co.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.Board.BoardDTO;
import kr.co.Board.BoardReplyDTO;
import kr.co.Board.BoardService;
import kr.co.Board.Criteria;
import kr.co.Board.PageMaker;

@Controller
public class BoardController {
	@Inject
	private BoardService boardService;
	
	//Q&A게시판 전체 목록 보기
	@RequestMapping(value = "board/QNAList", method = RequestMethod.GET )
	public String boardList(Model model)
	{
		List<BoardDTO> list = boardService.boardList();
		
		model.addAttribute("boardList", list);
		return "Board/QNAList";
	}	
	
	//Q&A게시판 선택 조회
	@RequestMapping(value = "board/BoardDetail", method = RequestMethod.GET)
	public String getBoardDetail(@RequestParam("b_number") int b_number, Model model)
	{
		
		boardService.boardReadCnt(b_number);	//조회수 증가
		System.out.println("============선택조회================");
		BoardDTO boardDTO = boardService.getBoardDetail(b_number);
		
		model.addAttribute("boardDetail",boardDTO);
				
		return "Board/BoardDetail";
	}
	
	//Q&A게시판 글쓰기
	@RequestMapping(value = "board/BoardRegister", method = RequestMethod.GET)
	public String boardRegister()
	{
		System.out.println("========글쓰기 GET==============");
		return "Board/BoardRegister";
	}
	
	//Q&A게시판 글쓰기
	@RequestMapping(value = "board/BoardRegister", method = RequestMethod.POST)
	public String boardRegister(BoardDTO boardDTO, RedirectAttributes rttr )
	{
		System.out.println("==========글쓰기 POST=============");	

		int r = boardService.boardRegister(boardDTO);
		
		if(r > 0)
		{
			rttr.addFlashAttribute("msg","추가에 성공하셨습니다.");
		}
		
		return "redirect:list_paging";
	}
	
	//Q&A게시판 글 수정
	@RequestMapping(value = "board/BoardUpdate", method = RequestMethod.GET)
	public String boardUpdate(int b_number, Model model)
	{
		model.addAttribute("b_number",b_number);
		return "Board/BoardUpdate";
	}
	
	//Q&A게시판 글 수정
	@RequestMapping(value = "board/BoardUpdate", method = RequestMethod.POST)
	public String boardUpdate(BoardDTO boardDTO)
	{		
		boardService.boardUpdate(boardDTO);
		
		return "redirect:BoardDetail?b_number="+boardDTO.getB_number();
	}
	
	//Q&A게시판 글 삭제
	@RequestMapping(value = "board/BoardDelete", method = RequestMethod.GET)
	public String boardDelete(@RequestParam("b_number") int b_number)
	{		
		System.out.println("============글삭제 Post============");
		
		boardService.boardDelete(b_number);
		
		return "redirect:QNAList";
	}
	
	//Q&A게시판 좋아요	
	@ResponseBody
	@RequestMapping(value = "board/BoardLike", method = RequestMethod.POST)
	public String boardLike(int b_number,int b_like)
	{		
		String result = "success";
		
		if(b_like == 0)
		{
			boardService.boardLikeCnt(b_number);
			boardService.boardLike(b_number);
		}
		else if(b_like == 1)
		{
			boardService.boardHateCnt(b_number);
			boardService.boardHate(b_number);
		}
		
		System.out.println(b_number + "============게시글 좋아요 POST============" + b_like);
		return result;
	}
	
	///////////////////////////댓   글///////////////////////////////////////////////////
	
	//댓글 조회
	@ResponseBody
	@RequestMapping(value = "board/getReply", method=RequestMethod.POST)
	public List<BoardReplyDTO> getReply(@RequestParam("b_number") int b_number) {
		
		return boardService.getReply(b_number);
	}
	
	//댓글추가
	@ResponseBody
	@RequestMapping(value = "board/replyRegister", method=RequestMethod.POST)
	public Map<String,Object> replyRegister(BoardReplyDTO boardReplyDTO) {
		
		Map<String,Object> result = new HashMap<String, Object>();
		System.out.println("=======댓글 추가==========");
		try {
			boardService.replyRegister(boardReplyDTO);
			result.put("status", "ok");
		}catch(Exception e){
			e.printStackTrace();
			result.put("status", "ok");
		}
		return result;
	}
	
	//댓글수정
	@ResponseBody
	@RequestMapping(value = "board/replyUpdate", method=RequestMethod.POST)
	public Map<String,Object> replyUpdate(BoardReplyDTO boardReplyDTO) {
		
		Map<String,Object> result = new HashMap<String, Object>();
		System.out.println("=============댓글 수정================");
		try {
			boardService.replyRegister(boardReplyDTO);
			result.put("status", "ok");
		}catch(Exception e){
			e.printStackTrace();
			result.put("status", "ok");
		}
		boardService.replyUpdate(boardReplyDTO);
		
		return result;
	}
	
	//댓글 삭제
	@ResponseBody
	@RequestMapping(value = "board/deleteReply", method=RequestMethod.POST)
	public Map<String,Object> deleteReply(int re_number) {
		
		Map<String,Object> result = new HashMap<String, Object>();
		System.out.println("=============댓글 삭제================");
		try {
			boardService.replyDelete(re_number);			
			result.put("status", "ok");
		}catch(Exception e){
			e.printStackTrace();
			result.put("status", "ok");
		}	
		
		return result;
	}
	
	//페이징/////////////////////////////////////////////////////////////////////////////////////////

	
	@RequestMapping(value = "board/list_paging", method = RequestMethod.GET)
	public String listPaging(Model model, Criteria criteria) throws Exception {

		//게시판 글 총 갯수 가져오기
		List<BoardDTO> list = boardService.boardList();
		
	    PageMaker pageMaker = new PageMaker();
	    //criteria = 게시글 출력 갯수
	    //pageMaker = 하단에 페이징 갯수
	    //생성된 criteria 객체를 pageMaker에 등록
	    pageMaker.setCriteria(criteria);
	    //총 게시글 갯수에 맞춰서 페이징 출력 갯수 정하기
	    pageMaker.setTotalCount(list.size());

	    model.addAttribute("boardList", boardService.listCriteria(criteria));
	    model.addAttribute("pageMaker", pageMaker);

	    return "Board/QNAList";
	}
}
















package kr.co.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.Member.MemberDTO;
import kr.co.Member.MemberService;

@Controller
public class MemberController {

	@Inject
	public MemberService memberService;
	
	@Autowired
	public KakaoAPI kakao;
	
	// 모든 회원 보기
	@RequestMapping(value="Admin/memberList", method = RequestMethod.GET)
	public String memberList(Model model){
			
		List<MemberDTO> list = memberService.memberList();
		model.addAttribute("memberList", list);
			
		return "Admin/memberList";
	}
	
	// 로그인 폼이동 GET
	@RequestMapping(value="Member/LoginForm", method = RequestMethod.GET)
	public String LoginForm() {
		System.out.println("로그인 폼으로 이동");
		return "Member/LoginForm";
	}
	
	// 로그인 처리 POST
	@RequestMapping(value="Member/LoginForm", method = RequestMethod.POST)
	public String LoginForm(@RequestParam Map<String, String> map, HttpServletRequest request, 
			HttpServletResponse reponse, HttpSession session) throws Exception {
		
		Map<String, String> member = memberService.login(map);

		if(member == null) {
			System.out.println("로그인 실패");
			return "redirect:LoginForm";
		} else {
			session.setAttribute("member", member);
			System.out.println("로그인 성공");
			System.out.println(member);
			return "redirect:/";
		}
	}
	
	//카카오
	@RequestMapping(value="/kakaoLogin")
	public String kakaoLogin(@RequestParam("code") String code, HttpSession session) {
		String access_Token = kakao.getAccessToken(code);
	    HashMap<String, Object> userInfo = kakao.getUserInfo(access_Token);
	    System.out.println("login Controller : " + userInfo);
	    
	    //    클라이언트의 이메일이 존재할 때 세션에 해당 이메일과 토큰 등록
	    if (userInfo.get("nickname") != null) {
	        session.setAttribute("userId", userInfo.get("nickname"));
	        session.setAttribute("access_Token", access_Token);
	    }
		
	    return "home";
	}
	
	//카카오 로그아웃
	@RequestMapping(value="/kakaoLogout")
	public String kakaoLogout(HttpSession session) {
	    kakao.kakaoLogout((String)session.getAttribute("access_Token"));
//	    session.removeAttribute("access_Token");
//	    session.removeAttribute("userId");
	    session.invalidate();
	    return "home";
	}

	
	// 로그아웃
	@RequestMapping(value="Member/Logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	// 이용약관
	@RequestMapping(value="Member/SignUp1", method= RequestMethod.GET)
	public String signUp1() {
			
		return "Member/SignUp1";
	}
	
	// 회원가입 GET
		@RequestMapping(value="Member/SignUp2", method= RequestMethod.GET)
		public String signUp() {
			
			return "Member/SignUp2";
		}
		
	// 회원가입 POST
	@RequestMapping(value="Member/SignUp2", method = RequestMethod.POST)
	public String signUp(MemberDTO memberDTO, RedirectAttributes rttr) {
		
		int r = memberService.memberInsert(memberDTO);
		
		if(r>0)
		{
			rttr.addFlashAttribute("msg", "회원가입되었습니다.");
		}
		
		return "redirect:LoginForm";
	}
	
	// 아이디 유효성 검사
	@ResponseBody
	@RequestMapping(value="Member/idChecking", method = RequestMethod.POST)
	public Map<String, Object> idChecking(String mb_id) {

		int count = 0;
		Map<String, Object> map = new HashMap<String, Object>();
			
		count = memberService.idChecking(mb_id);
		map.put("cnt", count);
		
		return map;
	}
}

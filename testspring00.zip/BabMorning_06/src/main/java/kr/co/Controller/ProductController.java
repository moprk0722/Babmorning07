package kr.co.Controller;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import kr.co.Member.MemberDTO;
import kr.co.Member.MemberService;
import kr.co.Product.CartDTO;
import kr.co.Product.CartJoinDTO;
import kr.co.Product.ProductDTO;
import kr.co.Product.ProductService;

@Controller
public class ProductController {
	
	@Inject
	private ProductService productService;
	private MemberService memberService;
	
	//상품 출력하기
	@RequestMapping(value="home", method=RequestMethod.GET)
	public String Home(Model model) {
		
		List<ProductDTO> list =productService.productList();
		
		model.addAttribute("ProductList", list);
		
		return "home";
	}
	
	//상품 출력하기
	@RequestMapping(value="Product/ProductList", method=RequestMethod.GET)
	public String ProductList(Model model) {
		
		List<ProductDTO> list =productService.productList();
		
		model.addAttribute("ProductList", list);
		
		return "Product/ProductList";
	}
	
	//상품 추가(하이퍼링크)
	@RequestMapping(value="Product/ProductInsert", method=RequestMethod.GET)
	public String ProductInsert() {
		System.out.println("상품추가============================================");
		return "Product/ProductInsert";
	}
	
	//상품 추가(서브밋)
	@RequestMapping(value="Product/ProductInsert", method=RequestMethod.POST)
	public String ProductInsert(MultipartHttpServletRequest mtf,ProductDTO productDTO) {
		
		// 파일 태그
		String fileTag = "up_upload";
		String str = productDTO.getPd_name();
	    // 업로드 파일이 저장될 경로
		String filePath = "D:\\CL\\jspworkspace\\BabMorning_06\\src\\main\\webapp\\resources\\upload\\";
		
		// 파일 이름	
		MultipartFile file = mtf.getFile(fileTag);
		
		String fileName = "("+str+")"+file.getOriginalFilename();
		
		// 파일 전송
		try {
		    file.transferTo(new File(filePath + fileName));

		} catch(Exception e) {
		    System.out.println("업로드 오류");
		}
		productDTO.setPd_img(fileName);
		productService.productInsert(productDTO);

		return "redirect:ProductList";
	}
	
	//상품 상세정보 보기
	@RequestMapping(value="Product/ProductDetail", method=RequestMethod.GET)
	public String ProductDetail(Model model, int pd_number) {
		
		ProductDTO productDTO = productService.productGetDetail(pd_number);
		
		model.addAttribute("product",productDTO);
		
		return "Product/ProductDetail";
	}
	
	//상품 수정(하이퍼링크)
	@RequestMapping(value="Product/ProductUpdate", method=RequestMethod.GET)
	public String ProductUpdate(Model model, int pd_number) {
		
		ProductDTO productDTO = productService.productGetDetail(pd_number);
		
		model.addAttribute("product", productDTO);
		
		return "Product/ProductUpdate";
	}
	
	//상품 수정
	@RequestMapping(value="Product/ProductUpdate", method=RequestMethod.POST)
	public String ProductUpdate(MultipartHttpServletRequest mtf,ProductDTO productDTO) {
		// 파일 태그
		String fileTag = "up_upload";
		String str = productDTO.getPd_name();
	    // 업로드 파일이 저장될 경로
		String filePath = "D:\\CL\\jspworkspace\\BabMorning_06\\src\\main\\webapp\\resources\\upload\\";
		
		// 파일 이름	
		MultipartFile file = mtf.getFile(fileTag);
		
		String fileName = "("+str+")"+file.getOriginalFilename();
		
		// 파일 전송
		try {
		    file.transferTo(new File(filePath + fileName));

		} catch(Exception e) {
		    System.out.println("업로드 오류");
		}
		productDTO.setPd_img(fileName);
		productService.productUpdate(productDTO);
		
		return "redirect:ProductList";
	}

	//상품 삭제
	@RequestMapping(value="Product/ProductDelete", method=RequestMethod.GET)
	public String ProductDelete(int pd_number) {
		
		productService.productDelete(pd_number);
		
		return "redirect:ProductList";
	}
	
	////////////////////덧글//////////////////////////////
	//덧글 출력
//	@ResponseBody
//	@RequestMapping(value="ProductReply", method=RequestMethod.POST)
//	public String pd_replyList(int pd_number,Model model) {
//		
//		return "ProductReply";
//	}
	
	////////////////////장바구니 기능//////////////////////////////
	//장바구니 추가
	@RequestMapping(value="Product/ProductDetail", method=RequestMethod.POST)
	public String CartInsert(CartDTO cartDTO, @RequestParam("mb_number") int mb_number) {
		
		System.out.println("장바구니 추가 컨트롤러");
		productService.cartInsert(cartDTO);
		
		return "redirect:ProductDetail?pd_number="+cartDTO.getPd_number();
	} 
	
	//장바구니 조회
	@RequestMapping(value="Product/CartView", method=RequestMethod.GET)
	public String CartView(HttpSession session, Model model) {
		Map map = (Map)session.getAttribute("member");
		int mb_number = (int)map.get("mb_number");
		
		List list = productService.cartDetail(mb_number);
		model.addAttribute("list", list);
		return "Product/CartView";
	}
	
	//총 가격 구하기
	@RequestMapping(value="Product/CartView", method=RequestMethod.POST)
	@ResponseBody
	public String CartView(int pd_number) {
		
		System.out.println("1111111111111111111111111111");
		productService.productGetDetail(pd_number);
		
		return "Product/CartView";
	}
	
	//장바구니 조회
	@RequestMapping(value="Product/CartView2", method=RequestMethod.GET)
	public String CartView2(HttpSession session, Model model) {
		Map map = (Map)session.getAttribute("member");
		int mb_number = (int)map.get("mb_number");
		
		return "Product/CartView2";
	}
	
	//장바구니 조회
	@RequestMapping(value="Product/CartView2", method=RequestMethod.POST)
	@ResponseBody
	public List<CartJoinDTO> CartView2(@RequestParam("mb_number") int mb_number) {
		
		return productService.cartDetail(mb_number);
	}
	
	//장바구니 조회
	@RequestMapping(value="Product/CartGetDetail", method=RequestMethod.POST)
	@ResponseBody
	public CartJoinDTO CartGetDetail(@RequestParam("cart_number") int cart_number) {
		
		return productService.cartGetDetail(cart_number);
	}
	

}

package kr.co.Product;

public class ProductDTO {

	private int pd_number;
	private String pd_id;
	private String pd_name;
	private int pd_price;
	private String pd_category;
	private String pd_memo;
	private String pd_detail;
	private String pd_company;
	private int pd_stock;
	private String pd_img;
	
	private String up_upload;

	public int getPd_number() {
		return pd_number;
	}
	public void setPd_number(int pd_number) {
		this.pd_number = pd_number;
	}
	public String getPd_id() {
		return pd_id;
	}
	public void setPd_id(String pd_id) {
		this.pd_id = pd_id;
	}
	public String getPd_name() {
		return pd_name;
	}
	public void setPd_name(String pd_name) {
		this.pd_name = pd_name;
	}
	public int getPd_price() {
		return pd_price;
	}
	public void setPd_price(int pd_price) {
		this.pd_price = pd_price;
	}
	public String getPd_category() {
		return pd_category;
	}
	public void setPd_category(String pd_category) {
		this.pd_category = pd_category;
	}
	public String getPd_memo() {
		return pd_memo;
	}
	public void setPd_memo(String pd_memo) {
		this.pd_memo = pd_memo;
	}
	public String getPd_detail() {
		return pd_detail;
	}
	public void setPd_detail(String pd_detail) {
		this.pd_detail = pd_detail;
	}
	public String getPd_company() {
		return pd_company;
	}
	public void setPd_company(String pd_company) {
		this.pd_company = pd_company;
	}
	public int getPd_stock() {
		return pd_stock;
	}
	public void setPd_stock(int pd_stock) {
		this.pd_stock = pd_stock;
	}
	public String getPd_img() {
		return pd_img;
	}
	public void setPd_img(String pd_img) {
		this.pd_img = pd_img;
	}
	
	
}

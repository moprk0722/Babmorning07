package kr.co.Product;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;

public interface ProductDAO {

	//전체 목록 불러오기
	public List<ProductDTO> productList();
	
	//선택한 상품 정보 가져오기
	public ProductDTO productGetDetail(int productNumber);
	
	//상품 추가
	public int productInsert(ProductDTO productDTO);
	
	//상품 수정
	public int productUpdate(ProductDTO productDTO);
	
	//상품 삭제
	public int productDelete(int pd_number);
	
	/////////////////////장바구니 기능//////////////////////
	//장바구니 추가
	public int cartInsert(CartDTO cartDTO);
	
	//장바구니 조회
	public List<CartJoinDTO> cartDetail(int mb_number);
	
	//장바구니 선택시 정보
	public CartJoinDTO cartGetDetail(int cart_number);
	
	//장바구니 수정
	
	//장바구니 삭제
	
}

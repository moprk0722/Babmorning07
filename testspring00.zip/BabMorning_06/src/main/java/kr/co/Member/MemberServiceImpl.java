package kr.co.Member;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService{

	@Inject
	private MemberDAO memberDAO;
	
	// 로그인
	@Override
	public Map<String, String> login(Map<String, String> map) {
		// TODO Auto-generated method stub
		return memberDAO.login(map);
	}

	// 전체 회원 보기
	@Override
	public List<MemberDTO> memberList() {
		// TODO Auto-generated method stub
		return memberDAO.memberList();
	}

	// 회원 추가
	@Override
	public int memberInsert(MemberDTO memberDTO) {
		// TODO Auto-generated method stub
		return memberDAO.memberInsert(memberDTO);
	}

	// 아이디 유효성 검사
	@Override
	public int idChecking(String mb_id) {
		// TODO Auto-generated method stub
		System.out.println(mb_id);
		return memberDAO.idChecking(mb_id);
	}

	// 회원 번호를 통해 회원 정보 모두 가져오기
	@Override
	public MemberDTO getMember_number(int mb_number) {
		// TODO Auto-generated method stub
		return memberDAO.getMember_number(mb_number);
	}
	
	
}


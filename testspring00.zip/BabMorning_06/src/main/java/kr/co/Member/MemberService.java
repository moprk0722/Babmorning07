package kr.co.Member;

import java.util.List;
import java.util.Map;

import kr.co.Product.CartJoinDTO;

public interface MemberService {
	// 로그인
	public Map<String, String> login(Map<String, String> map) throws Exception;
	
	// 전체 회원
	public List<MemberDTO> memberList();
	
	// 회원 추가
	public int memberInsert(MemberDTO memberDTO);
	
	// 아이디 유효성 검사
	public int idChecking(String mb_id);
	
	// 회원번호로 회원 정보 가져오기
	public MemberDTO getMember_number(int mb_number);
}

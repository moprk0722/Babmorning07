package kr.co.Member;

import java.util.List;
import java.util.Map;

import kr.co.Product.CartJoinDTO;

public interface MemberDAO {
	
	// 로그인
	public Map<String, String> login(Map<String, String> map);

	// 전체 회원 조회
	public List<MemberDTO> memberList();
	
	// 회원 추가
	public int memberInsert(MemberDTO memberDTO);

	// 유효성 검사
	public int idChecking(String mb_id);
	
	public MemberDTO getMember_number(int mb_number);
}

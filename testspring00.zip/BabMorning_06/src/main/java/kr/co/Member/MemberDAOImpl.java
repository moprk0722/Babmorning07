package kr.co.Member;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAOImpl implements MemberDAO{

	@Inject
	private SqlSession sqlSession;
	
	//로그인
	@Override
	public Map<String, String> login(Map<String, String> map) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("Member.login", map);
	}
		
	//회원전체 보기
	@Override
	public List<MemberDTO> memberList() {
		// TODO Auto-generated method stub
		return sqlSession.selectList("Member.memberList");
	}

	//회원 추가	
	@Override
	public int memberInsert(MemberDTO memberDTO) {
		// TODO Auto-generated method stub
		return sqlSession.insert("Member.insert", memberDTO);
	}

	@Override
	public int idChecking(String mb_id) {
		// TODO Auto-generated method stub
		System.out.println(mb_id);
		return sqlSession.selectOne("Member.idChecking", mb_id);
	}

	@Override
	public MemberDTO getMember_number(int mb_number) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne("Member.getMember_number", mb_number);
	}


}
